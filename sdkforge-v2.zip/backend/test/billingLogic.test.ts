import test from 'node:test';
import assert from 'node:assert/strict';
import {
  PLANS, tierFromPriceId, mapStripeStatus, resolveProfileUpdate, downgradeToStarter, isUuid, isPaidTier
} from '../src/billingLogic.ts';

const prices = { growth_pro: 'price_growth', enterprise_scale: 'price_ent' };

test('plan matrix matches the commercial offer', () => {
  assert.equal(PLANS.starter.monthlyQuota, 20);
  assert.equal(PLANS.growth_pro.monthlyQuota, 500);
  assert.equal(PLANS.growth_pro.priceUsdPerMonth, 49);
  assert.equal(PLANS.enterprise_scale.monthlyQuota, null);
  assert.equal(PLANS.enterprise_scale.priceUsdPerMonth, 249);
});

test('price id mapping', () => {
  assert.equal(tierFromPriceId('price_growth', prices), 'growth_pro');
  assert.equal(tierFromPriceId('price_ent', prices), 'enterprise_scale');
  assert.equal(tierFromPriceId('price_other', prices), null);
  assert.equal(tierFromPriceId(undefined, prices), null);
});

test('status mapping fails closed', () => {
  assert.equal(mapStripeStatus('active'), 'active');
  assert.equal(mapStripeStatus('past_due'), 'past_due');
  assert.equal(mapStripeStatus('something_new'), 'incomplete');
  assert.equal(mapStripeStatus(null), 'incomplete');
});

test('active paid subscription grants its quota', () => {
  assert.deepEqual(resolveProfileUpdate('growth_pro', 'active'), {
    plan_tier: 'growth_pro', monthly_quota: 500, subscription_status: 'active'
  });
  assert.deepEqual(resolveProfileUpdate('enterprise_scale', 'trialing'), {
    plan_tier: 'enterprise_scale', monthly_quota: null, subscription_status: 'trialing'
  });
});

test('past_due keeps tier, canceled/unpaid downgrade to starter', () => {
  assert.equal(resolveProfileUpdate('growth_pro', 'past_due').plan_tier, 'growth_pro');
  for (const s of ['canceled', 'unpaid', 'incomplete_expired'] as const) {
    const r = resolveProfileUpdate('enterprise_scale', s);
    assert.equal(r.plan_tier, 'starter');
    assert.equal(r.monthly_quota, 20);
    assert.equal(r.subscription_status, s);
  }
  assert.equal(downgradeToStarter().subscription_status, 'canceled');
});

test('validators', () => {
  assert.equal(isUuid('3f2b8c1e-8a1d-4c0e-9d57-1c2f3a4b5c6d'), true);
  assert.equal(isUuid("1'; drop table profiles;--"), false);
  assert.equal(isPaidTier('growth_pro'), true);
  assert.equal(isPaidTier('starter'), false);
  assert.equal(isPaidTier('hacker'), false);
});
